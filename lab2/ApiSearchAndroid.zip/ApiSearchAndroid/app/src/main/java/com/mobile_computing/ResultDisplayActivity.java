package com.mobile_computing;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.squareup.picasso.Picasso;

import java.util.Objects;

public class ResultDisplayActivity extends AppCompatActivity {

    private TextView favoritesStatusText;
    private ImageButton addRemoveFavoritesButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_display);

        // Getting all data from intent
        int id = getIntent().getIntExtra("id", 0);
        String title = getIntent().getStringExtra("title");
        String date = getIntent().getStringExtra("date");
        String text = getIntent().getStringExtra("text");
        String imageUrl = getIntent().getStringExtra("imageUrl");

        // Setting up the action bar
        // 1. Enabling the back button
        // 2. Enabling the title and setting it.
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setTitle(title);
        }

        // View declarations
        TextView titleText = findViewById(R.id.tv_title);
        TextView dateText = findViewById(R.id.tv_date);
        TextView textText = findViewById(R.id.tv_text);
        ImageView imageView = findViewById(R.id.iv_image);
        favoritesStatusText = findViewById(R.id.tv_favorite_status);
        addRemoveFavoritesButton = findViewById(R.id.starButton);

        // Setting data to the appropriate views
        titleText.setText(title);
        dateText.setText(date);
        textText.setText(text);
        Picasso.get().load(imageUrl).fit().centerCrop().into(imageView);

        // Check and update UI if the current item is favorite or not.
        checkFavoriteStatus(id);
    }

    private void checkFavoriteStatus(int id) {
        if (FavoritesManager.isInFavorites(id)) {
            favoritesStatusText.setText(R.string.added_to_favorites);
            addRemoveFavoritesButton.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_star_filled));
            addRemoveFavoritesButton.setOnClickListener(view -> {
                boolean status = FavoritesManager.removeFromFavorites(id);
                if (status) {
                    Toast.makeText(getApplicationContext(), R.string.removed_from_favorites, Toast.LENGTH_SHORT).show();
                    checkFavoriteStatus(id);
                }
            });
        } else {
            favoritesStatusText.setText(R.string.not_in_favorites);
            addRemoveFavoritesButton.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_star_unfilled));
            addRemoveFavoritesButton.setOnClickListener(view -> {
                boolean status = FavoritesManager.addToFavorites(id);
                if (status) {
                    Toast.makeText(getApplicationContext(), R.string.added_to_favorites, Toast.LENGTH_SHORT).show();
                    checkFavoriteStatus(id);
                }
            });
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // Back button in the actionbar.
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}