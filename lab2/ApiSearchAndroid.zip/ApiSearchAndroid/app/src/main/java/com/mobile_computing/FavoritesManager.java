package com.mobile_computing;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FavoritesManager {
    private static final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(MobileComputingApplication.getApplication());

    /**
     * Returns a list of items added as a favorite by the user.
     * Favorites are stored as a comma separated string in Shared Preferences
     * @return a list of ID strings of books added as favorites.
     **/
    private static List<String> getFavorites() {
        if(preferences.contains("favorites")) {
            String favoritesArrayString = preferences.getString("favorites", "");
            if (favoritesArrayString != null) {
                return new ArrayList<>(Arrays.asList(favoritesArrayString.split(",")));
            }
        }

        return new ArrayList<>();
    }

    /**
     * Builds a comma separated string using the list of IDs provided.
     * It then stores the same in Shared Preferences.
     * @param favorites the list of IDs marked as favorite.
     **/
    private static void setFavorites(List<String> favorites) {
        StringBuilder favoritesToSet = new StringBuilder();
        for (String id:favorites) {
            favoritesToSet.append(id);
            if(favorites.indexOf(id) < favorites.size() - 1) {
                favoritesToSet.append(",");
            }
        }
        preferences.edit().putString("favorites", favoritesToSet.toString()).commit();
    }

    /**
     * Adds an ID to the list of favorites and updates it in Shared Preferences.
     * @param id the ID of the item marked as favorite.
     * @return true if save was success, false otherwise
     **/
    public static boolean addToFavorites(int id) {
        List<String> favorites = getFavorites();
        String idString = String.valueOf(id);
        if(!favorites.contains(idString)) {
            favorites.add(idString);
            setFavorites(favorites);
            return true;
        }
        return false;
    }

    /**
     * Removes an ID to the list of favorites and updates it in Shared Preferences.
     * @param id the ID of the item removed from favorite.
     * @return true if remove was success, false otherwise.
     **/
    public static boolean removeFromFavorites(int id) {
        List<String> favorites = getFavorites();
        String idString = String.valueOf(id);
        if(favorites.contains(idString)) {
            favorites.remove(idString);
            setFavorites(favorites);
            return true;
        }
        return false;
    }

    /**
     * Checks if given ID exists in the list of favorites.
     * @param id the ID of the item to be searched im favorites.
     * @return true if item in the list, false otherwise.
     **/
    public static boolean isInFavorites(int id) {
        return getFavorites().contains(String.valueOf(id));
    }
}
